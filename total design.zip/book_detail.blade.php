<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>MedicalBooksOnline.Net</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs/themes/prism.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css/animate.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/noty/lib/noty.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/noty/lib/themes/relax.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <!--    <link rel="stylesheet" href="css/bootstrap.min.css">-->

    <link rel="stylesheet" href="{{ asset('assets/sidebar-css-js/css/metismenujs.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/sidebar-css-js/css/app.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/sidebar-css-js/css/mm-vertical.css') }}" />

    <!-- Custom CSS Link -->
    <link rel="stylesheet" href="{{ asset('assets/css/style2.css') }}">

    <!-- Custom CSS for responsive -->
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">

</head>

<body>

    <header id="menu_part">
        <nav class="navbar main_menu main_menu-fixed navbar-expand-lg p-0">
            <div class="container px-0">
                <a class="navbar-brand" href="{{ route('home') }}" action="{{ route('home') }}">
                    <img class="" src="../assets/img/logo_white.png" alt="logo">
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav m-auto m-sm-0">
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('home') }}" action="{{ route('home') }}">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Last Hour 7th Edition Volume-I</a>
                        </li>
                    </ul>

                    <!--Search option for books-->
                    <div class="ml-auto user__part">
                        <form class="form-inline my-2 my-lg-0 search_box-wrapper">
                            <div class="input-group mb-0">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <svg class="bi bi-search" width="1em" height="1em" viewBox="0 0 16 16"
                                            fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M10.442 10.442a1 1 0 011.415 0l3.85 3.85a1 1 0 01-1.414 1.415l-3.85-3.85a1 1 0 010-1.415z"
                                                clip-rule="evenodd" />
                                            <path fill-rule="evenodd"
                                                d="M6.5 12a5.5 5.5 0 100-11 5.5 5.5 0 000 11zM13 6.5a6.5 6.5 0 11-13 0 6.5 6.5 0 0113 0z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </div>
                                <input id="myInput" class="form-control mr-0 search_box" type="search"
                                    placeholder="Search topic, chapter, subject" aria-label="Search"
                                    onkeyup="myFunction()">
                            </div>
                            <!--    <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button> -->
                        </form>

                        <div class="profile_menu">
                            <a class="profile" href="#profile">
                                <i class="fa fa-user-circle"></i> <span>Profile</span>
                            </a>
                            <a class="log__out" title="Sign Out"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log
                                Out</a>
                            <form id="logout-form" action="{{ url('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>


    <div class="page__content">
        <section>
            <div class="container-fluid p-md-0">
                <div class="row">
                    <div class="col-lg-3 col-md-4">
                        <nav class="sidebar-nav sidebar_menu">
                            <ul class="metismenu" id="menu1">
                                @foreach($subjects as $subject)
                                <li>
                                    <a class="has-arrow" href="#" aria-expanded="false">{{ $subject->subject_name }}</a>
                                    <ul>
                                        @foreach($subject->chapters as $chapter)
                                        <li>
                                            <a class="has-arrow" href="#"
                                                aria-expanded="false">{{ $chapter->chapter_name }}</a>
                                            <ul>
                                                @foreach($chapter->topics as $topic)
                                                <li>
                                                    <a href="#">{{ $topic->topic_name }}</a>
                                                </li>
                                                @endforeach
                                            </ul>
                                        </li>
                                        @endforeach
                                    </ul>
                                </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>

                    <div id="book__body" class="col-lg-9 col-md-8 col-sm-12 book_body">
                        <div id="section1">
                            <br />
                            <h4 id="item-1">HISTOLOGY</h4>
                            <br />

                            <div class="Q">
                                <h5><span>1</span>. Skeletal muscle contraction (MD, Basic, Paediatrics March 2019)</h5>
                                <ul>
                                    <li>a) Needs the Z-bands coming closer</li>
                                    <li>b) Requires calcium ions to bind to tropomyosin</li>
                                    <li>c) Cannot end in rigor mortis due to lack of energy</li>
                                    <li>d) Is more sustained in antigravity muscle than is running muscle</li>
                                    <li>e) May be voluntary or involuntary</li>
                                </ul>
                                <br /><br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Ans.
                                </button>

                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <span>T F F T T</span>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample2" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Explanation:
                                </button>

                                <div class="collapse" id="collapseExample2">
                                    <div class="card card-body">
                                        <ul>
                                            <li>a) Z lines come closer together</li>
                                            <li>b) Binding of Ca<sup>2+</sup> to troponin C, uncovering myosing sites on
                                                action (Inhibition of troponin-tropomyosin complex)</li>
                                            <li>c) Rigor mortis (Stiffness of muscle after death) occurs if no ATP
                                                (energy) is available</li>
                                        </ul>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample3" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Comment
                                </button>

                                <div class="collapse comment_btn" id="collapseExample3">
                                    <textarea class="form-control" name="" id="" rows="5"></textarea>
                                    <button class="btn btn-primary send_btn">Submit</button>
                                </div>

                                <br />
                                <p><i>Dr. User:</i> This is awesome but also need night mode.</p>
                                <span>22m</span>
                                <br /><br />
                                <br /><br />
                            </div>
                        </div>

                        <div id="section2">
                            <br />
                            <h4 id="item-1">EMBRYOLOGY</h4>
                            <br />

                            <div class="Q">
                                <h5><span>2</span>. Skeletal muscle contraction (MD, Basic, Paediatrics March 2019)</h5>
                                <ul>
                                    <li>a) Needs the Z-bands coming closer</li>
                                    <li>b) Requires calcium ions to bind to tropomyosin</li>
                                    <li>c) Cannot end in rigor mortis due to lack of energy</li>
                                    <li>d) Is more sustained in antigravity muscle than is running muscle</li>
                                    <li>e) May be voluntary or involuntary</li>
                                </ul>
                                <br /><br />



                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Ans.
                                </button>

                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <span>T F F T T</span>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample2" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Explanation:
                                </button>

                                <div class="collapse" id="collapseExample2">
                                    <div class="card card-body">
                                        <ul>
                                            <li>a) Z lines come closer together</li>
                                            <li>b) Binding of Ca<sup>2+</sup> to troponin C, uncovering myosing sites on
                                                action (Inhibition of troponin-tropomyosin complex)</li>
                                            <li>c) Rigor mortis (Stiffness of muscle after death) occurs if no ATP
                                                (energy) is available</li>
                                        </ul>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample3" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Comment
                                </button>

                                <div class="collapse comment_btn" id="collapseExample3">
                                    <textarea class="form-control" name="" id="" rows="5"></textarea>
                                    <button class="btn btn-primary send_btn">Submit</button>
                                </div>

                                <br />
                                <p><i>Dr. User:</i> This is awesome but also need night mode.</p>
                                <span>22m</span>
                                <br /><br />
                                <br /><br />
                            </div>
                        </div>

                        <div id="section3">
                            <br />
                            <h4 id="item-1">THORAX</h4>
                            <br />

                            <div class="Q">
                                <h5><span>3</span>. Skeletal muscle contraction (MD, Basic, Paediatrics March 2019)</h5>
                                <ul>
                                    <li>a) Needs the Z-bands coming closer</li>
                                    <li>b) Requires calcium ions to bind to tropomyosin</li>
                                    <li>c) Cannot end in rigor mortis due to lack of energy</li>
                                    <li>d) Is more sustained in antigravity muscle than is running muscle</li>
                                    <li>e) May be voluntary or involuntary</li>
                                </ul>
                                <br /><br />



                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Ans.
                                </button>

                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <span>T F F T T</span>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample2" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Explanation:
                                </button>

                                <div class="collapse" id="collapseExample2">
                                    <div class="card card-body">
                                        <ul>
                                            <li>a) Z lines come closer together</li>
                                            <li>b) Binding of Ca<sup>2+</sup> to troponin C, uncovering myosing sites on
                                                action (Inhibition of troponin-tropomyosin complex)</li>
                                            <li>c) Rigor mortis (Stiffness of muscle after death) occurs if no ATP
                                                (energy) is available</li>
                                        </ul>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample3" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Comment
                                </button>

                                <div class="collapse comment_btn" id="collapseExample3">
                                    <textarea class="form-control" name="" id="" rows="5"></textarea>
                                    <button class="btn btn-primary send_btn">Submit</button>
                                </div>

                                <br />
                                <p><i>Dr. User:</i> This is awesome but also need night mode.</p>
                                <span>22m</span>
                                <br /><br />
                                <br /><br />
                            </div>
                        </div>

                        <div id="section41">
                            <br />
                            <h4 id="item-1">EXTREMITY-ONE</h4>
                            <br />

                            <div class="Q">
                                <h5><span>4</span>. Skeletal muscle contraction (MD, Basic, Paediatrics March 2019)</h5>
                                <ul>
                                    <li>a) Needs the Z-bands coming closer</li>
                                    <li>b) Requires calcium ions to bind to tropomyosin</li>
                                    <li>c) Cannot end in rigor mortis due to lack of energy</li>
                                    <li>d) Is more sustained in antigravity muscle than is running muscle</li>
                                    <li>e) May be voluntary or involuntary</li>
                                </ul>
                                <br /><br />



                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Ans.
                                </button>

                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <span>T F F T T</span>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample2" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Explanation:
                                </button>

                                <div class="collapse" id="collapseExample2">
                                    <div class="card card-body">
                                        <ul>
                                            <li>a) Z lines come closer together</li>
                                            <li>b) Binding of Ca<sup>2+</sup> to troponin C, uncovering myosing sites on
                                                action (Inhibition of troponin-tropomyosin complex)</li>
                                            <li>c) Rigor mortis (Stiffness of muscle after death) occurs if no ATP
                                                (energy) is available</li>
                                        </ul>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample3" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Comment
                                </button>

                                <div class="collapse comment_btn" id="collapseExample3">
                                    <textarea class="form-control" name="" id="" rows="5"></textarea>
                                    <button class="btn btn-primary send_btn">Submit</button>
                                </div>

                                <br />
                                <p><i>Dr. User:</i> This is awesome but also need night mode.</p>
                                <span>22m</span>
                                <br /><br />
                                <br /><br />
                            </div>
                        </div>

                        <div id="section42">
                            <br />
                            <h4 id="item-1">EXTREMITY-TWO</h4>
                            <br />

                            <div class="Q">
                                <h5><span>5</span>. Skeletal muscle contraction (MD, Basic, Paediatrics March 2019)</h5>
                                <ul>
                                    <li>a) Needs the Z-bands coming closer</li>
                                    <li>b) Requires calcium ions to bind to tropomyosin</li>
                                    <li>c) Cannot end in rigor mortis due to lack of energy</li>
                                    <li>d) Is more sustained in antigravity muscle than is running muscle</li>
                                    <li>e) May be voluntary or involuntary</li>
                                </ul>
                                <br /><br />



                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Ans.
                                </button>

                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <span>T F F T T</span>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample2" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Explanation:
                                </button>

                                <div class="collapse" id="collapseExample2">
                                    <div class="card card-body">
                                        <ul>
                                            <li>a) Z lines come closer together</li>
                                            <li>b) Binding of Ca<sup>2+</sup> to troponin C, uncovering myosing sites on
                                                action (Inhibition of troponin-tropomyosin complex)</li>
                                            <li>c) Rigor mortis (Stiffness of muscle after death) occurs if no ATP
                                                (energy) is available</li>
                                        </ul>
                                    </div>
                                </div>

                                <br />

                                <button class="btn btn-primary d-block" type="button" data-toggle="collapse"
                                    data-target="#collapseExample3" aria-expanded="false"
                                    aria-controls="collapseExample">
                                    Comment
                                </button>

                                <div class="collapse comment_btn" id="collapseExample3">
                                    <textarea class="form-control" name="" id="" rows="5"></textarea>
                                    <button class="btn btn-primary send_btn">Submit</button>
                                </div>

                                <br />
                                <p><i>Dr. User:</i> This is awesome but also need night mode.</p>
                                <span>22m</span>
                                <br /><br />
                                <br /><br />
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>


    </div>

    <footer>
        <p class="text-center">
            Copyright &copy; 2020;
        </p>
    </footer>






    <script>
        // //my_books counter
        // (function () {
        //     const mainDiv = document.getElementById("card_part");
        //     const myBooks = mainDiv.getElementsByClassName("my_books");
        //     let target = document.querySelector('.main_menu .navbar-nav .nav-item .nav-link span');
        //     target.innerHTML = " (" + myBooks.length + ") ";
        // })();

        //header search box
        function myFunction() {
            let input, filter, wrapper, item, value, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            wrapper = document.getElementById("book__body");
            item = wrapper.getElementsByTagName("div");
            for (i = 0; i < item.length; i++) {
                value = item[i].getElementsByTagName("h4")[0];
                txtValue = value.textContent || value.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    item[i].style.display = "";
                } else {
                    item[i].style.display = "none";
                }
            }
        }
    </script>









    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <!--    <script src="js/jquery-1.12.4.min.js"></script>-->
    <!--    <script src="js/popper.min.js"></script>-->
    <!--    <script src="js/bootstrap.min.js"></script>-->


    <!-- jQuery plugins for filter-->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/mixitup/3.3.1/mixitup.min.js"></script> -->

    <!--    <script src="js/mixitup.min.js"></script>-->


    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/prismjs/prism.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/noty/lib/noty.min.js"></script>

    <script src="{{ asset('assets/sidebar-css-js/js/metismenujs.js') }}"></script>
    <script src="{{ asset('assets/sidebar-css-js/js/mm-vertical.js') }}"></script>

    <!-- <script src="js/script.js"></script> -->

    <script>
        // var containerEl = document.querySelector('.filter_box');

        // var mixer = mixitup(containerEl);
    </script>
</body>

</html>